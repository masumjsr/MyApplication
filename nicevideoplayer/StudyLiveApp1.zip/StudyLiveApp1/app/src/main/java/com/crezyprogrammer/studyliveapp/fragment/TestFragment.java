package com.crezyprogrammer.studylive.fragment;


import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.fragment.app.Fragment;

import com.crezyprogrammer.studyliveapp.NoticeActivity;
import com.crezyprogrammer.studyliveapp.R;
import com.crezyprogrammer.studyliveapp.fragment.ListenFragment;
import com.crezyprogrammer.studyliveapp.fragment.QuizPracticeFragment;
import com.crezyprogrammer.studyliveapp.fragment.WrittingFragment;

import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * A simple {@link Fragment} subclass.
 */
public class TestFragment extends Fragment {



    public TestFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_test, container, false);
        ButterKnife.bind(this, view);
        return view;
    }


    @OnClick({R.id.reading, R.id.listening,R.id.writting,R.id.notice})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.reading:
            getActivity().startActivity(new Intent(getActivity(),QuizPracticeFragment.class));
                break;
                case R.id.notice:
            getActivity().startActivity(new Intent(getActivity(), NoticeActivity.class));
                break;
            case R.id.listening:

             getActivity().startActivity(new Intent(getActivity(),ListenFragment.class));
                break;
            case R.id.writting:

           //getActivity().startActivity(new Intent(getActivity(), WrittingFragment.class));

           AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getActivity());
           // ...Irrelevant code for customizing the buttons and title
           LayoutInflater inflater = this.getLayoutInflater();
           View dialogView = inflater.inflate(R.layout.translate, null);
           dialogBuilder.setView(dialogView);




           AlertDialog     alertDialog = dialogBuilder.create();
                Button button=dialogView.findViewById(R.id.button1);
                Button button2=dialogView.findViewById(R.id.button2);

                button.setOnClickListener(v -> {
                    Intent intent =new Intent(getActivity(),WrittingFragment.class);
                    intent.putExtra("mode","b2e");
                    startActivity(intent);
                    alertDialog.dismiss();
                });
                button2.setOnClickListener(v -> {
                    Intent intent =new Intent(getActivity(),WrittingFragment.class);
                    intent.putExtra("mode","e2b");
                    startActivity(intent);
                    alertDialog.dismiss();
                });
                alertDialog.show();
                break;
        }
    }
}
