package com.crezyprogrammer.studyliveapp;

import android.app.ProgressDialog;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.squareup.picasso.Picasso;

import butterknife.BindView;
import butterknife.ButterKnife;
import fm.jiecao.jcvideoplayer_lib.JCVideoPlayer;
import fm.jiecao.jcvideoplayer_lib.JCVideoPlayerStandard;

public class VideoActivity extends AppCompatActivity {
    String name;
    @BindView(R.id.recycler)
    RecyclerView recycler;
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);
        ButterKnife.bind(this);
        name = getIntent().getStringExtra("name");

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("loading");
        progressDialog.show();
        Log.i("123321", "41: "+name);
        setupDatabase();
    }

    private void setupDatabase() {
        LinearLayoutManager manager = new LinearLayoutManager(this);
        recycler.setLayoutManager(manager);
        Query query = FirebaseDatabase.getInstance().getReference("admin/video").child(name);
        FirebaseRecyclerOptions options = new FirebaseRecyclerOptions.Builder<VideoModel>().setQuery(query, snapshot -> new VideoModel(snapshot.child("image").getValue().toString(), snapshot.child("name").getValue().toString(), snapshot.child("video").getValue().toString())).build();
        FirebaseRecyclerAdapter adapter = new FirebaseRecyclerAdapter<VideoModel, ViewHolder>(options) {

            @NonNull
            @Override
            public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.video_layout, parent, false));
            }

            @Override
            public void onDataChanged() {
                progressDialog.dismiss();
            }

            @Override
            protected void onBindViewHolder(@NonNull ViewHolder viewHolder, int i, @NonNull VideoModel VideoModel) {
                viewHolder.details(VideoModel);
            }
        };

        recycler.setAdapter(adapter);
        adapter.startListening();

    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        JCVideoPlayerStandard jcVideoPlayerStandard;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            jcVideoPlayerStandard = itemView.findViewById(R.id.videoplayer);
        }

        public void details(VideoModel videoModel) {
            Log.i("123321", "82"+videoModel.getImage()+"\n"+videoModel.getName()+"\n"+videoModel.getVideo());

          jcVideoPlayerStandard.setUp(videoModel.getVideo()
                  , JCVideoPlayerStandard.SCREEN_LAYOUT_NORMAL, videoModel.getName());

          jcVideoPlayerStandard.thumbImageView.setImageURI(Uri.parse("http://10.0.2.2/fileload/w1.jpg"));
          Picasso.get().load(videoModel.getImage()).into(jcVideoPlayerStandard.thumbImageView);

        }
    }
    @Override
    public void onBackPressed() {
        if (JCVideoPlayer.backPress()) {
            return;
        }
        super.onBackPressed();
    }
    @Override
    protected void onPause() {
        super.onPause();
        JCVideoPlayer.releaseAllVideos();
    }
}
