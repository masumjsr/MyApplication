package com.crezyprogrammer.studyliveapp;

public class ListMOdel {
    String name;

    public String getName() {
        return name;
    }

    public ListMOdel(String name) {
        this.name = name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ListMOdel() {
    }
}
