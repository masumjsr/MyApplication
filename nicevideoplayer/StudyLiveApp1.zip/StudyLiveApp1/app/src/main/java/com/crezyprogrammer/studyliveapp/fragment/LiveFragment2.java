package com.crezyprogrammer.studyliveapp.fragment;


import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.crezyprogrammer.studyliveapp.ListMOdel;
import com.crezyprogrammer.studyliveapp.R;
import com.crezyprogrammer.studyliveapp.VideoActivity;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * A simple {@link Fragment} subclass.
 */
public class LiveFragment2 extends AppCompatActivity {


    @BindView(R.id.recycler)
    RecyclerView recycler;
    ProgressDialog progressDialog;
String type;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    setContentView(R.layout.fragment_live2);
        ButterKnife.bind(this);

        progressDialog = new ProgressDialog(this);
        type=getIntent().getStringExtra("type");
        progressDialog.setMessage("loading");
        progressDialog.show();
        setupDatabase();


    }

    private void setupDatabase() {
        LinearLayoutManager manager=new LinearLayoutManager(getApplicationContext());
        recycler.setLayoutManager(manager);
        Query query= FirebaseDatabase.getInstance().getReference("admin/list").child(type);
        FirebaseRecyclerOptions options=new FirebaseRecyclerOptions.Builder<ListMOdel>().setQuery(query, snapshot -> new ListMOdel(snapshot.child("name").getValue().toString())).build();
        FirebaseRecyclerAdapter adapter=new FirebaseRecyclerAdapter<ListMOdel,ViewHolder>(options) {

            @NonNull
            @Override
            public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.videolist,parent,false));
            }

            @Override
            public void onDataChanged() {
                super.onDataChanged();
                progressDialog.dismiss();
            }

            @Override
            protected void onBindViewHolder(@NonNull ViewHolder viewHolder, int i, @NonNull ListMOdel listMOdel) {
viewHolder.details(listMOdel);
            }
        };
        recycler.setAdapter(adapter);
        adapter.startListening();

    }
    public  class ViewHolder extends RecyclerView.ViewHolder {
        TextView name;
        RelativeLayout layout;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name=itemView.findViewById(R.id.name);
            layout=itemView.findViewById(R.id.main);
        }

        public void details(ListMOdel listMOdel) {
            name.setText(listMOdel.getName());
            layout.setOnClickListener(v -> {
                Intent intent=new Intent(getApplicationContext(), VideoActivity.class);
                intent.putExtra("name",type+"/"+listMOdel.getName());
              startActivity(intent);
            });

        }
    }

}
