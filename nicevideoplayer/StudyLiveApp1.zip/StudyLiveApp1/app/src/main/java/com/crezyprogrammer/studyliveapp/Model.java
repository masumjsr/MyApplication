package com.crezyprogrammer.studyliveapp;

import android.widget.Toast;

public class Model {
   static int i;





    public static int getI() {
        return i;
    }

    public static  void setI(int i2) {
        i = i2;
    }
}
